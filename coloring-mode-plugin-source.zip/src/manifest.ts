import type { PluginManifestRef } from "@lighttable/plugin-sdk";

export const runtimeManifest: PluginManifestRef = {
  id: "com.lighttable.coloring",
  version: "1.0.0",
  apiVersionRange: "^1.0.0",
};

export const PLUGIN_ID = runtimeManifest.id;
export const REGION_NODE_TYPE = "com.lighttable.coloring.region";
export const REGION_NODE_VERSION = 1;
export const STORAGE_KEY = "workspace-v1";
export const COLOR_RENDER_LAYER_ID = "coloring-regions";
